# Backend for my-protofolio website

[![CircleCI](https://circleci.com/gh/munezerobagira/mybrand-backend/tree/main.svg?style=svg)](https://circleci.com/gh/munezerobagira/mybrand-backend/tree/main) [![Coverage Status](https://coveralls.io/repos/github/munezerobagira/mybrand-backend/badge.svg?branch=develop)](https://coveralls.io/github/munezerobagira/mybrand-backend?branch=develop) [![Reviewed by Hound](https://img.shields.io/badge/Reviewed_by-Hound-8E64B0.svg)](https://houndci.com) [![Maintainability](https://api.codeclimate.com/v1/badges/cff3cb21941a378a0fa4/maintainability)](https://codeclimate.com/github/munezerobagira/mybrand-backend/maintainability)

## About project

API for the personal website sharing the projects and articles.

### Users

- #### Guest

  - can login
  - can add, edit, delete his/her comments on the post

- #### Ownner

  - what admin can do

- #### admin
  - can create, update, delete and project
  - can create, update, delete and post
  - can add the comment
  - is admin

