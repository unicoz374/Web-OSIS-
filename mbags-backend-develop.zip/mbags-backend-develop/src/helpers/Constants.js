export const INTERNAL_SERVER_ERROR = "Internal server error";
export const TOKEN_ERROR = "invalid token";
export const UNSUPPORTED_IMAGE_FORMAT = "Unsupported image format";
