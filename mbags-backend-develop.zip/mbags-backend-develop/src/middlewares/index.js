export { default as joiValidator } from "./joiValidator";
